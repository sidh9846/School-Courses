/*
 -------------------------------------
 File:    mysort.h
 Project: a4
 file description
 -------------------------------------
 Author:  Manveer Sidhu
 ID:      169029846
 Email:   sidh9846@mylaurier.ca
 Version  2024-02-09
 -------------------------------------
 */
#ifndef MYSORT_H_
#define MYSORT_H_

void select_sort_inc(float *a[], int left, int right);

void quick_sort_inc(float *a[], int left, int right);

#endif /* MYSORT_H_ */
